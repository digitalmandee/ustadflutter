import 'dart:io';

import 'package:dio/dio.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutterustad/Helpers/static_data.dart';
import 'package:flutterustad/Screens/Authentication/apple_signIn_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutterustad/Custom widgets/app_button.dart';
import 'package:flutterustad/Custom widgets/app_text.dart';
import 'package:flutterustad/Helpers/app_theme.dart';
import 'package:flutterustad/Helpers/capitalize.dart';
import 'package:flutterustad/Helpers/loader.dart';
import 'package:flutterustad/Helpers/utils.dart';
import 'package:flutterustad/Screens/Authentication/SignUP/google_signup_detail.dart';
import 'package:flutterustad/Screens/Authentication/SignUP/sign_up_screen.dart';
import 'package:flutterustad/Screens/Authentication/google_signin.dart';
import 'package:flutterustad/Screens/Authentication/widgets/auth_widgets.dart';
import 'package:flutterustad/Screens/Authentication/Forgot Pass/forgot_pass.dart';
import 'package:flutterustad/Screens/Authentication/otp.dart';
import 'package:flutterustad/Screens/BottomNavBar/bottom_bar.dart';
import 'package:flutterustad/Screens/Parents Screens/Parents OnBoard/parents_onboard.dart';
import 'package:flutterustad/Screens/Teacher Screens/0nBoard Screens/tutor_on_board.dart';
import 'package:flutterustad/config/dio/app_logger.dart';
import 'package:flutterustad/config/dio/dio.dart';
import 'package:flutterustad/config/keys/global.dart';
import 'package:flutterustad/config/keys/pref_keys.dart';
import 'package:flutterustad/config/keys/urls.dart';

class LogInScreen extends StatefulWidget {
  final bool showLogoutMessage;
  const LogInScreen({super.key, this.showLogoutMessage = false});

  @override
  State<LogInScreen> createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool isLoading = false;
  bool _isGoogleLoading = false;

  late AppDio dio;
  late GoogleSignInService _googleSignInService;
  final AppLogger logger = AppLogger();

  bool _isAppleLoading = false;
  late AppleSignInService _appleSignInService;

  @override
  void initState() {
    super.initState();
    dio = AppDio(context);
    if (widget.showLogoutMessage) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        AppToast.success(context: context, msg: "Logged out successfully");
      });
    }
    getDeviceToken();
    isTokenRefresh();
    _googleSignInService = GoogleSignInService.instance;
    _googleSignInService.init();
    _appleSignInService = AppleSignInService.instance;
    _appleSignInService.init();
    logger.init();
  }

  FirebaseMessaging messaging = FirebaseMessaging.instance;
  Future<String> getDeviceToken() async {
    try {
      String? token = await messaging.getToken();
      if (token != null) {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString("fcm_token", token);
        return token;
      }
    } catch (e) {
      print("Error getting device token: $e");
    }
    return "";
  }

  void isTokenRefresh() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    messaging.onTokenRefresh.listen((event) {
      event.toString();
      prefs.setString("fcm_token", event);
      if (kDebugMode) {}
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            authHeader(
              context: context,
              isSignInScreen: true,
              onEmailTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => SignupScreen()),
                );
              },
              onGoogleTap: () async {
                setState(() => _isGoogleLoading = true);
                final userData = await _googleSignInService.signIn(context);
                if (userData != null) {
                  push(context, GoogleSignupDetail(userData: userData));
                }
                if (mounted) {
                  setState(() => _isGoogleLoading = false);
                }
              },
              onAppleTap: () async {
                setState(() => _isAppleLoading = true);
                final userData = await _appleSignInService.signIn(context);
                if (userData != null) {
                  push(context, GoogleSignupDetail(userData: userData));
                }
                if (mounted) {
                  setState(() => _isAppleLoading = false);
                }
              },
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 30.h),
              child: Column(
                children: [
                  customLableField(
                    lable: "Email",
                    controller: _emailController,
                  ),
                  const SizedBox(height: 20),
                  customLableField(
                    lable: "Password",
                    isPassword: true,
                    controller: _passwordController,
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (!Staticdata.isActive)
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    ForgotPassScreen(isEditing: false),
                              ),
                            );
                          },
                          // =>
                          //     push(context, ForgotPassScreen(isEditing: false)),
                          child: AppText.appText(
                            "Forgot Password?",
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            textColor: AppTheme.appColor,
                          ),
                        ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 30.0),
                    child: isLoading
                        ? GifLoader()
                        : AppButton.appButton(
                            "Sign In",
                            context: context,
                            onTap: () => _emailSignIn(context),
                            border: false,
                            backgroundColor: AppTheme.primaryCOlor,
                          ),
                  ),
                  if (Staticdata.guestmood) ...[
                    GestureDetector(
                      onTap: () => _guestSignIn(context),
                      child: Center(
                        child: Text(
                          "Continue as Parent Guest",
                          style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.primaryCOlor,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                  loginDivider("Or login with"),
                  const SizedBox(height: 30),

                  _isGoogleLoading
                      ? const GifLoader()
                      : AppButton.appButton(
                          "Google",
                          context: context,
                          onTap: () async {
                            setState(() => _isGoogleLoading = true);
                            final userData = await _googleSignInService.signIn(
                              context,
                            );
                            if (userData != null) {
                              await _googleSignIn(context, userData);
                            }
                            if (mounted) {
                              setState(() => _isGoogleLoading = false);
                            }
                          },
                          fontWeight: FontWeight.w600,
                          textColor: AppTheme.lableText,
                          borderColor: AppTheme.borderCOlor,
                          backgroundColor: AppTheme.white,
                          image: "assets/images/google.png",
                        ),

                  Platform.isAndroid
                      ? const SizedBox.shrink()
                      : const SizedBox(height: 16),
                  Platform.isAndroid
                      ? const SizedBox.shrink()
                      : _isAppleLoading
                      ? const GifLoader()
                      : AppButton.appButton(
                          "Apple",
                          context: context,
                          onTap: () async {
                            setState(() => _isAppleLoading = true);

                            final userData = await _appleSignInService.signIn(
                              context,
                            );

                            if (userData != null) {
                              await _appleSignIn(context, userData);
                            }

                            if (mounted) {
                              setState(() => _isAppleLoading = false);
                            }
                          },
                          fontWeight: FontWeight.w600,
                          textColor: AppTheme.lableText,
                          borderColor: AppTheme.borderCOlor,
                          backgroundColor: AppTheme.white,
                          image: "assets/images/apple.png",
                        ),

                  const SizedBox(height: 40),
                  const SizedBox(height: 40),
                  loginFooter(context),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _emailSignIn(context) async {
    setState(() => isLoading = true);

    final email = _emailController.text.trim().toLowerCase();
    final password = _passwordController.text.trim();

    final emailPattern = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (email.isEmpty || !emailPattern.hasMatch(email)) {
      AppToast.error(
        context: context,
        msg: "Please enter a valid email address.",
      );
      setState(() => isLoading = false);
      return;
    }
    if (password.isEmpty) {
      AppToast.error(context: context, msg: "Please enter password");
      setState(() => isLoading = false);
      return;
    }

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      final fcmTokenget = prefs.getString('fcm_token');

      final response = await dio.post(
        path: AppUrls.logIn,
        data: {"email": email, "password": password},
        options: Options(
          headers: {
            "Content-Type": "application/json",
            "deviceId": fcmTokenget ?? "", // Use FCM token instead of device-id
          },
        ),
      );

      if (response.statusCode == 200) {
        await _handleLoginSuccess(context, response.data);
      } else {
        (context, "Something went wrong");

        AppToast.error(
          context: context,
          msg: "${response.data["errors"][0]["message"]}",
        );
      }
    } catch (e) {
      String message = "Something went wrong";

      if (e is DioException) {
        message = e.error?.toString() ?? "Check Internet Connection";
      } else {
        message = e.toString();
      }

      AppToast.error(context: context, msg: message);
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Map<String, String> splitName(String displayName) {
    if (displayName.trim().isEmpty) {
      return {"firstName": "", "lastName": ""};
    }

    List<String> parts = displayName.trim().split(RegExp(r'\s+'));

    String firstName = parts.first;
    String lastName = parts.length > 1 ? parts.sublist(1).join(' ') : '';

    return {
      "firstName": capitalizeEachWord(firstName),
      "lastName": capitalizeEachWord(lastName),
    };
  }

  Future<void> _guestSignIn(BuildContext context) async {
    try {
      final response = await dio.postJson(path: AppUrls.guestLogin, data: {});

      if (!context.mounted) return;
      if (response.statusCode == 200) {
        await _handleLoginSuccess(context, response.data, isGuestLogin: true);
      } else {
        AppToast.error(
          context: context,
          msg: response.data?["message"] ?? "Guest login failed",
        );
      }
    } catch (e) {
      if (!context.mounted) return;
      AppToast.error(context: context, msg: "Guest login failed");
    }
  }

  Future<void> _googleSignIn(context, Map<String, dynamic> userData) async {
    try {
      // final role = await _selectUserRole(context);
      final name = splitName(userData["displayName"] ?? "");

      // if (role == null) return;

      final response = await dio.post(
        path: AppUrls.googleSignIn,
        data: {
          "email": userData["email"],
          "googleId": userData["id"],
          "firstName": name["firstName"],
          "lastName": name["lastName"],
          "image": userData["photoUrl"] ?? "",
          "accessToken": userData["idToken"] ?? "",
          // "role": role.toUpperCase(),
        },
      );

      if (response.statusCode == 200) {
        await _handleLoginSuccess(context, response.data);
      } else {
        AppToast.error(
          context: context,
          msg: "${response.data["errors"][0]["message"]}",
        );
      }
    } catch (_) {
      if (!context.mounted) return;

      AppToast.error(
        context: context,
        msg: "Something went wrong. Please try again.",
      );
    }
  }

  Future<void> _handleLoginSuccess(
    BuildContext context,
    Map<String, dynamic> responseData, {
    bool isGuestLogin = false,
  }) async {
    final data = responseData["data"];
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(PrefKey.authorization, data["token"] ?? '');
    await prefs.setString(PrefKey.id, "${data["id"] ?? ''}");
    await prefs.setString(PrefKey.userRole, data["role"] ?? '');
    await prefs.setString(PrefKey.userFirstName, data["firstName"] ?? '');
    await prefs.setString(PrefKey.userLastName, data["lastName"] ?? '');
    await prefs.setString(PrefKey.userPic, data["image"] ?? '');
    await prefs.setString(PrefKey.onBoard, data["isOnBoard"] ?? '');
    await prefs.setString(PrefKey.isGoogleId, data["googleId"] ?? '');
    await prefs.setBool('is_guest', isGuestLogin);

    globalUserId = "${data["id"] ?? ''}";
    globalUserFirstName = data["firstName"];
    globalUserLastName = data["lastName"];
    globalUserRole = data["role"];
    globalToken = data["token"];
    globalUserPic = data["image"] ?? '';
    globalUserOnBoardStatus = data["isOnBoard"] ?? '';
    // globalGoogleId = data["googleId"] ?? "";
    globalGoogleId = data["googleId"] ?? data["appleId"] ?? "";
    isGuest = isGuestLogin;

    if (!context.mounted) return;

    if (data["isEmailVerified"] == false) {
      push(
        context,
        OtpScreen(
          userId: "${data["id"]}",
          fromEditProfile: false,
          email: data["email"],
        ),
      );
    } else if (data["isOnBoard"] == "required" && data["role"] == "TUTOR") {
      push(context, TutorOnboardScreen());
    } else if (data["isOnBoard"] == "required" && data["role"] == "PARENT") {
      push(context, ParentsOnboardScreen());
    } else if (data["role"] == "TUTOR") {
      pushReplacement(context, BottomNavView(tutor: true));
    } else if (data["role"] == "PARENT" || data["role"] == "GUEST") {
      pushReplacement(context, BottomNavView(tutor: false));
    }
  }

  Future<void> _appleSignIn(context, Map<String, dynamic> userData) async {
    try {
      final name = splitName(userData["displayName"] ?? "");

      final response = await dio.post(
        path: AppUrls.googleSignIn,
        data: {
          "email": (userData["email"] ?? "").toString().trim().toLowerCase(),

          // Because your backend is using the same API for Google and Apple
          "googleId": userData["appleId"] ?? userData["id"],

          // Keep this also if backend supports appleId
          "appleId": userData["appleId"] ?? userData["id"],

          "firstName": userData["firstName"] ?? name["firstName"],
          "lastName": userData["lastName"] ?? name["lastName"],
          "image": userData["photoUrl"] ?? "",
          "accessToken": userData["idToken"] ?? userData["identityToken"] ?? "",
          "identityToken": userData["identityToken"] ?? "",
          "authorizationCode": userData["authorizationCode"] ?? "",
        },
      );

      if (response.statusCode == 200) {
        await _handleLoginSuccess(context, response.data);
      } else {
        AppToast.error(
          context: context,
          msg: "${response.data["errors"][0]["message"]}",
        );
      }
    } catch (e) {
      if (!context.mounted) return;

      if (kDebugMode) {
        print("Apple Sign-In API Error: $e");
      }

      AppToast.error(
        context: context,
        msg: "Something went wrong. Please try again.",
      );
    }
  }
}
